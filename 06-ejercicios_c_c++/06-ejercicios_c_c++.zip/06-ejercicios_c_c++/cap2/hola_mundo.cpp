#include <iostream> //Para el std::cout

int main() {

    std::cout << "¡Hola, Mundo!" << std::endl;

    return 0;
}
