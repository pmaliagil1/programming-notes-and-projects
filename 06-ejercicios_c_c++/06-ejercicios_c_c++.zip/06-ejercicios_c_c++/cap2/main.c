#include <stdio.h>  // Obligatorio para printf
#include <stdlib.h> //Para el system("Pause")

int main() {

    printf("¡Hola, Mundo!\n");

    system("pause"); //Con esta pausa consigo que el archivo .exe no se cierre del tirón.
    return 0;
}

// Comentario de una linea

/*Comentario de varias lineas*/