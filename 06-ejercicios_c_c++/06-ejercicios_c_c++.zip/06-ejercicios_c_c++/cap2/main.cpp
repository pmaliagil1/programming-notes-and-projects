#include <iostream> //Para el std::cout
#include <cstdlib>  //Para el system("Pause")

int main() {

    std::cout << "¡Hola, Mundo!" << std::endl;

    system("pause");
    return 0;
}
