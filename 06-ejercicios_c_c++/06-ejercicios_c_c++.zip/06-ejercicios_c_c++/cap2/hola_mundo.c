#include <stdio.h>  // Obligatorio para printf

int main() {

    printf("¡Hola, Mundo!\n");

    return 0;
}