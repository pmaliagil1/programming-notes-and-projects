/*float y double pueden ser datos negativos, imagina que el empleado debe dinero a la empresa 
o que el coche circula marcha atrás*/

int main(){
    double sueldo_bruto_anual = -1500.1;
    float velocidad_coche = -8.15;
    return 0;
}