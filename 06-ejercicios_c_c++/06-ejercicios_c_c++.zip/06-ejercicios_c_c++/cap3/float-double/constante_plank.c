/*puedes recurrir a double para notacion científica que combina digitos con caracteres*/

int main(){
    double constante_plank = 6.626e-34;
    return 0;
}