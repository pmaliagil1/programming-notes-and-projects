/*para calculos precisos usar DOUBLE (calculos financieros/científicos)
usar FLOAT cuando no hace falta ser tan preciso ya que ocupa menos espacio en memoria (graficos)*/

int main(){
    double sueldo_bruto_anual = 3000.50;
    return 0;
}