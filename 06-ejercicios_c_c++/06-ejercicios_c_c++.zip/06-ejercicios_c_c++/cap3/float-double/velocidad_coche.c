/*en el caso de querer calcular la velocidad a la que va un coche, la precision queda en un 
segundo plano, de hecho con un par de decimales suele ser suficiente, por lo que en este caso
lo que mas convendría usar es un float*/

int main(){
    float velocidad_coche = 108.42;
    return 0;
}