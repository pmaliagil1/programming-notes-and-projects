/*void sirve para representar la ausencia de valor, al tratar de compilar el siguiente codigo
dara un error, void cobrará mas sentido en los proximos ejercicios*/

/*
int main(){
    void variable_sin_tipo;
    return 0;
}
    */