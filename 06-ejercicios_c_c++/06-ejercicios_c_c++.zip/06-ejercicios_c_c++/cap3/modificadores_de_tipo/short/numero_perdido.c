/*el modificador short se utiliza cuando queremos reducir el rango disponible del entero al que
acompaña, puede ser util para ahorrar espacio en memoria en situaciones en las que sabemos que
trabajaremos con numeros en un rango pequeño*/

int main(){
    short int numero_perdido = 108;
    return 0;
}