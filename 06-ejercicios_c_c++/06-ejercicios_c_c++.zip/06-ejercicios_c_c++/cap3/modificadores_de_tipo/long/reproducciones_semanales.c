/*long es un modificador de tipo que amplia el rango de valores disponibles del tipo
al que acompaña*/

int main(){
    long int reproducciones_semanales = 4815162342;
    return 0;
}

/*en situaciones donde necesitas un entero aun mas grande, puedes declarar con
dos modificadores long*/

int main(){
    long long int reproducciones_semanales = 4815162342108;
    return 0;
}