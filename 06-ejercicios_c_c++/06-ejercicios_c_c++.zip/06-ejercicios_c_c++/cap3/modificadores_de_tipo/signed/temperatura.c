/*el modificador signed indica que el tipo puede ser positivo o negativo,
dado que la mayoria de tipos disponen de signos por defecto llega a ser redundante*/

int main(){
    signed char temperatura = -15;
    return 0;
}