/*Declara una variable double para representar un precio con impuestos*/

int main(){
    double precio = 29.99;
    return 0;
}