/*Modele un entero que almacene el identificador 47*/

int main(){
    int id = 47;
    return 0;
}