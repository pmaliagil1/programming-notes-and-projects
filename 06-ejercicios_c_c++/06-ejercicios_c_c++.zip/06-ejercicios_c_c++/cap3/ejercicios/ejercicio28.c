/*¿Cuantos hermanos o hermanas tienes? Declara una variable e inicializala
con tu respuesta*/

int main(){
    int hermanos = 1;
    return 0;
}