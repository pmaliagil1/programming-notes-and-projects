/*¿Porque todos los programas terminan con return 0*/

/* ¿Por qué usamos 'return 0'?
   El 'main' debe devolver un número entero al Sistema Operativo al finalizar.
   - 0: Significa "Éxito", el programa terminó correctamente sin errores.
   - Otro valor (1, 2, etc.): Indica que algo falló durante la ejecución.
   En C++ moderno es opcional (el compilador lo añade solo), pero en C es 
   una buena práctica ponerlo siempre por compatibilidad. */