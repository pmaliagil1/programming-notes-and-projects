/*Crea una variable que almacene la bateria de tu movil*/

int main(){
    unsigned int bateria_movil = 77; //usamos unsigned ya que la bateria nunca puede ser negativa
    return 0;
}