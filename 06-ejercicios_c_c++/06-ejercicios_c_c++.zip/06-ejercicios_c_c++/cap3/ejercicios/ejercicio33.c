/*crea una variable char para representar una respuesta (S/N)*/

int main(){
    char respuesta = 'S';
    return 0;
}