/*Declara una variable en C que almacene el número favorito de Bender: 1729. Elige el tipo adecuado*/

int main(){
    int bender = 1729;
    return 0;
}