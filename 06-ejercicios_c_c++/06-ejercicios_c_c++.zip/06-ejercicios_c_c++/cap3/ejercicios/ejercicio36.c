/*Declara una constante entera llamada MAX_USUARIOS con el valor 108 y 
trata de modificar su contenido*/

int main(){
    const int MAX_USUARIOS = 108;
    //MAX_USUARIOS = 10;  No deja hacerlo ya que al ser una constante no es modificable
    return 0;
}