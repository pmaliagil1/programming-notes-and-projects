/*Declara una variable llamada nave en C++, de tipo caracter, e inicializala con el valot <T>*/

int main(){
    char nave = 'T';
    return 0;

}

/*En C++, las comillas no son intercambiables como en otros lenguajes (como Python o JavaScript):
'T' (Comillas simples): Se usan para un carácter individual (char). Es un solo byte.
"T" (Comillas dobles): Se usan para una cadena de texto (string). Aunque solo veas una letra,
 para el ordenador "T" es en realidad un conjunto que contiene la 'T' y un símbolo invisible de
"final de texto" (\0).*/