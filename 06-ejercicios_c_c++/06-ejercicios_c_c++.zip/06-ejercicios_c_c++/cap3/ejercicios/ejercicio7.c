//Define una constane en C que almacene la letra inicial de Heisenberg

int main(){
    const char letra_inicial = 'H';
    return 0;
}