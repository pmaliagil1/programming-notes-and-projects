/*¿Puedes crear una variable que almacene tu edad entera y sin signo?*/

int main(){
    unsigned int edad = 19;
    return 0;
}