/*Define una constante que almacene el valor del número e en ambos lenguajes (e = 2.71828)*/

int main(){
    const double e = 2.71828;
    return 0;
}