/*Declara una variable capaz de almacenar el salario mensual bruto de un empleado*/

int main(){
    double salario_mensual = 1500;
    return 0;
}

/* Se utiliza 'double' para el salario porque permite almacenar decimales 
   (céntimos) y ofrece mayor precisión que 'float' para cálculos 
   financieros, evitando errores de redondeo básicos. */