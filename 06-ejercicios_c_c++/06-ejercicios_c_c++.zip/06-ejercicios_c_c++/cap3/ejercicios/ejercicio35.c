/*¿Aceptas los terminos y condiciones en todos los programas que instalas en tu equipo?
Crea una variable de tipo bool que represente si un usuario ha aceptado los terminos y sus condiciones*/

#include <stdbool.h>
int main(){
    bool terminos_condiciones = true;
    return 0;
}