/*Declara una variable de tipo short y cambia su valor dos veces*/

int main(){
    short int variable = 32;
    variable = 11;
    variable = 7;
    return 0;
}