/*La velocidad de la luz en el vacio es una constante cuyo valor exacto es 299 792 458 m/s.
Define una variable en C++ que lo almacene*/

int main(){
    const double velocidad_luz = 299792458; //puede usarse int al no ser decimal
    return 0;
}