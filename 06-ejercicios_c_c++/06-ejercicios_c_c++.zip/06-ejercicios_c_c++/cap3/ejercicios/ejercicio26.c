/*Declara dos variables enteras y asignales valores distintos*/

int main(){
    int variable1 = 7;
    int variable2 = 19;
    return 0;
}