/*Crea una variable de tipo float en C capaz de almacenar la cantidad de explosivo necesario
para derribar una puerta (segun Jesse Pinkman,3.6)*/

int main(){
    float explosivo = 3.6;
    return 0;
}