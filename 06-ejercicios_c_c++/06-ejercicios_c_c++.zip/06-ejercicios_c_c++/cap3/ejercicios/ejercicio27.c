/*Crea una variable char que almacene el caracter de nueva linea \n*/


int main(){
char variable = '\n';
return 0;
}

/*
' ' (Comillas simples): Se usan para un solo carácter (char).

" " (Comillas dobles): Se usan para cadenas de texto (string o char[]).
*/