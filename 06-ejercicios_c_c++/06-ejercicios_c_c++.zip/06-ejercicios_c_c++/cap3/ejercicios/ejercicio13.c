/*Declara una variable de tipo bool llamada apagado y asignale el valor false en C*/

#include <stdbool.h>

int main(){
    bool apagado = false;
    return 0;
}