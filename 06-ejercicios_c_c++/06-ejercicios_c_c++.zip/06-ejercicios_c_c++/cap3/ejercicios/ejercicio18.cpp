/*Muestra la información del ejercicio anterior por pantalla. El resultado
esperado debe ser R2-D2*/
#include <iostream>
int main(){
    char variable1 = 'R';
    char variable2 = '2';
    char variable3 = 'D';
    char variable4 = '2';

    std::cout << variable1<<variable2<<"-"<<variable3<<variable4;
    return 0;
}