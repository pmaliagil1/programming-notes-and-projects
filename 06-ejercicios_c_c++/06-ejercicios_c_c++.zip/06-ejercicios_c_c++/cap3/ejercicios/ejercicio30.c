/*Construye las variables de tipo char necesarias para formar las palabras
VIDA PLENA. No olvides incluir el espacio. Muestra el mensaje en pantalla.*/

#include <stdio.h>
int main(){
    char variable1 = 'V';
    char variable2 = 'I';
    char variable3 = 'D';
    char variable4 = 'A';
    char variable5 = 'P', variable6 = 'L', variable7='E',variable8='N',variable9 = 'A';
    printf("%c%c%c%c %c%c%c%c%c",variable1,variable2,variable3,variable4,variable5,variable6,variable7,variable8,variable9);
    return 0;
}
//el espacio puede ir dentro de una variable en vez de en el print