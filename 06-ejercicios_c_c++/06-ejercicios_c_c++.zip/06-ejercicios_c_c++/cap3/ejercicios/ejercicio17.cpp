/*Declara cuatro variables que almacenen los caracteres R2-D2 en C++*/

int main(){
    char variable1 = 'R';
    char variable2 = '2';
    char variable3 = 'D';
    char variable4 = '2';

    return 0;
}