/*Encuentra el modo de mostrar los caracteres E3.23 en pantalla, en referencia
al ejercicio 3.23 del presente capitulo*/
#include <stdio.h>

int main(){
    printf("E3.23");
    return 0;
}