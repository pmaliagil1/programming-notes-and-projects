/*¿Que tipo elegirias para implementar el codigo postal de una ciudad*/

/* ¿Qué tipo usar para un código postal?
   - Aunque no tiene decimales, NO se recomienda 'int' porque los códigos 
     que empiezan por 0 (ej. 08001) perderían ese cero inicial.
   - Lo ideal es usar una cadena de texto (string o char array), ya que 
     es una etiqueta y no un valor para hacer cálculos matemáticos.
   - Si el libro exige un tipo numérico, se usaría 'unsigned int'. */