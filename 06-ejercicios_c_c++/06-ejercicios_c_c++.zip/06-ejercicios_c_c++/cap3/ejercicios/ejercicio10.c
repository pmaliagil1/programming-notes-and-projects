/*Declara una variable long long en C, dotala de contenido e imprimela en pantalla con %lld*/

#include <stdio.h>

int main(){
    long long int numero = 3000000000;
    printf("Numero: %lld",numero);
    return 0;

    
}