/*¿Y al contrario? ¿Que ocurre si asignas un valor de tipo int a una variable
de tipo real?*/

/*Que el valor se almacena correctamente solo que se expresa con 0 decimales*/