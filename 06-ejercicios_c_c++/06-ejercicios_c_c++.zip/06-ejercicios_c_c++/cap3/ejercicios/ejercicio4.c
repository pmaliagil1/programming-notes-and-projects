/*En varios episodios de Doctor Who se repite el numero 4.73 como el numero exacto de minutos
que quedan antes de que algo explote o se abra un determinado portal. ¿Con qué tipo
lo modelarias? ¿Porque? Implemente tu codigo en C*/

int main(){
    float minuto = 4.73;
    return 0;
}

/*Lo modelo con tipo float ya que no tiene uso cientifico ni economico, ademas de ser
un decimal bastante simple que puedo manejar perfectamente con float*/