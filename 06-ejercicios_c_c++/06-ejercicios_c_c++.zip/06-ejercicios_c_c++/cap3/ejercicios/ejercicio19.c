/*Muestra en pantalla las letras de tu nombre (una letra en cada fila)*/

#include <stdio.h>

int main(){
    printf("P\na\nb\nl\no");
    return 0;
}