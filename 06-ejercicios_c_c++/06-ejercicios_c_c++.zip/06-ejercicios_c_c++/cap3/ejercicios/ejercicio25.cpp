/*¿Te has dado cuenta de que los identificadores en C/C++ son case_sensitive?
Esto quiere decir que C/C++ diferencia entre mayusculas y minusculas.
Recupera el ejercicio 3.06 e intenta utilizar la variable NAVE (que no esta declarada)
en lugar de nave. ¿Que error de compilacion obtienes?*/

/*
int main(){
    char nave = 'T'; // Declaramos la variable en minúsculas
    
    // Intentamos usar la versión en mayúsculas que NO existe
    printf("%c", NAVE); 
    
    return 0;
}*/