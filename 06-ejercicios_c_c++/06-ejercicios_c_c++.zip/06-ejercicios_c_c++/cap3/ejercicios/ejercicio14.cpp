/*Convierte el ejercicio 3.10 a codigo C++*/


#include <iostream>

int main(){
    long long int numero = 3000000000;
    std::cout << "Numero: "<<numero;
    return 0;
}