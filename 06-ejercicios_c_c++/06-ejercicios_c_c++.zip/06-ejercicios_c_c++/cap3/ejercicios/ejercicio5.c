/*¿Que ocurre si muestras en pantalla la variable del ejercicio 3.02? Oh sorpresa...¡Cuantos ceros!*/
#include <stdio.h>

int main(){
    float explosivo = 3.6;
    printf("Explosivo: %f",explosivo);
    return 0;
}