#include <stdio.h>

int main(){
    int edad = 31;
    printf("Edad: %d",edad);
    return 0;
}