#include <iostream>

int main(){
    int edad = 30;
    std::cout <<"Edad: "<< edad;
    return 0;
}