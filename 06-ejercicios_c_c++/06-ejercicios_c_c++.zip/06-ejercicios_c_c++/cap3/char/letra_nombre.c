//imagina queremos almacenar la primera letra del nombre de una persona

int main(){
    char primera_letra = "E";
    return 0;
}


//Tambien podemos darle valor a la variable despues de declararla

int main(){
    char primera_letra;
    primera_letra = "E";
    return 0;
}