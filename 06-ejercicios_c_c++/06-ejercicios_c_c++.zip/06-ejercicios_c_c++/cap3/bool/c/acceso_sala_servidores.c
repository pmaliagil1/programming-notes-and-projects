/*a partir de C99 se implemento el tipo bool*/

# include <stdbool.h> //hay que añadir esta libreria para usar bool en C

int main(){
    bool acceso_sala_servidores = true; //usar [true/false]

    /*version alternativa:
    bool acceso_sala_servidores = 1;  //usar [1/0]
    */
    return 0;
}