/*antes de c99, no existia como tal el caracter bool, se asignaba a un int 0 o 1 en funcion de si era 
true o false */

int main (){
    int acceso_sala_servidores = 0; //0 para representar que NO tiene acceso
    return 0;
}

int main (){
    int acceso_sala_servidores = 1; //1 para representar que SI tiene acceso (se puede usar otro valor)
    return 0;
}