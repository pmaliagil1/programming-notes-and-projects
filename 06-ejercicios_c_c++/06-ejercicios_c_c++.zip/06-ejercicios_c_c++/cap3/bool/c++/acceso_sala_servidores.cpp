//En C++, bool fue introducido desde el principio por lo que no hacen falta encabezados

int main(){
    bool acceso_sala_servidores = true; //importante declarar la variable antes de modificarla
    acceso_sala_servidores = false;
    return 0;
}