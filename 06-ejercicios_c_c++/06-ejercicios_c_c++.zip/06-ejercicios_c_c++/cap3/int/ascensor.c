int main(){
    int planta_ascensor = -1;
    planta_ascensor = 15; //Al modificar una variable no es necesario volver a declararla
    return 0;
}