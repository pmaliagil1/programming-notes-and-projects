int main () {
    int edad = 31;
    return 0;
}