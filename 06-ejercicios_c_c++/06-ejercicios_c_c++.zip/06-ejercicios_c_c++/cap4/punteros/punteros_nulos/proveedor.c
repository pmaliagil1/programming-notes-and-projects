#include <stdio.h>
int main(){
    int *proveedor = NULL; //Con esto el puntero apunta a 0 (nada)
    printf("%p",proveedor);
    return 0;

}