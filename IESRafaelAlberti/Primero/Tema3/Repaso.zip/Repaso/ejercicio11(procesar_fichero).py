"""11. Ficheros
Procesar un fichero de texto usando listas
Dado un fichero de texto llamado datos.txt que contiene varias líneas con palabras separadas 
por espacios, se pide:
1. Leer el fichero y almacenar todas las palabras en una lista. 
2. Mostrar cuántas palabras hay en total. 
3. Crear una lista con las palabras únicas (sin repetir). 
4. Ordenar alfabéticamente la lista de palabras únicas. 
5. Mostrar los resultados. 
Contenido de ejemplo del fichero  datos.txt 
hola mundo esto es un ejemplo de fichero
python es un lenguaje poderoso y divertido
hola mundo python de ejemplo
Pista: Puedes utilizar otra estructura de datos auxiliar diferente a listas para realizar algún apartado. 
También te puedes inspirar en el ejercicio de clase sobre apertura y recorrido de ficheros"""
import os

def procesar_fichero(nombre_archivo):
    todas_las_palabras = []

    # 1. Leer el fichero y almacenar todas las palabras en una lista
    with open(nombre_archivo, "r", encoding="utf-8") as archivo:
        for linea in archivo:
            # .split() sin argumentos separa por cualquier espacio en blanco y quita los \n
            palabras_linea = linea.split()
            # Usamos .extend() para añadir los elementos de la lista individual a la general
            todas_las_palabras.extend(palabras_linea)

    # 2. Mostrar cuántas palabras hay en total
    total_palabras = len(todas_las_palabras)

    # 3. Crear una lista con las palabras únicas (usamos set como auxiliar)
    # 4. Ordenar alfabéticamente
    palabras_unicas = sorted(list(set(todas_las_palabras)))

    return todas_las_palabras, total_palabras, palabras_unicas

def crear_archivo_ejemplo(nombre):
    """Crea el archivo datos.txt si no existe para evitar errores."""
    contenido = (
        "hola mundo esto es un ejemplo de fichero\n"
        "python es un lenguaje poderoso y divertido\n"
        "hola mundo python de ejemplo"
    )
    with open(nombre, "w", encoding="utf-8") as f:
        f.write(contenido)
    print(f"--- Archivo '{nombre}' creado/verificado con éxito ---\n")

if __name__ == "__main__":
    nombre_fichero = "datos.txt"
    
    try:
        # Paso previo: nos aseguramos de que el fichero existe
        crear_archivo_ejemplo(nombre_fichero)
        
        # Procesamos
        lista_total, conteo, lista_ordenada = procesar_fichero(nombre_fichero)
        
        # 5. Mostrar los resultados
        print(f"1. Lista de todas las palabras:\n{lista_total}\n")
        print(f"2. Total de palabras encontradas: {conteo}\n")
        print(f"3 y 4. Palabras únicas ordenadas alfabéticamente:\n{lista_ordenada}")

    except Exception as e:
        print(f"Algo ha salido mal: {e}")