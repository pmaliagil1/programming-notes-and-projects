"""Escribir un programa que almacene las asignaturas de un curso (por ejemplo
Matemáticas, Física, Química, Historia y Lengua) en una lista y la muestre por pantalla.
"""

asignaturas = ["Matemáticas", "Física", "Química", "Historia", "Lengua"]
print(asignaturas)

#asignaturas.sort()
#asignaturas.severse()
#print(asignaturas.index(historia))