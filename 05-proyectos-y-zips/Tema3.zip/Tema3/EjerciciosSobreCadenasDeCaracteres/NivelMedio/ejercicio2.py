#Dado que fruta es una variable de tipo cadena, ¿qué significa fruta[:]?

"""En python, a las cadenas puedes hacer algo llamado slicing, para entenderlo mejor, : en una cadena
se lee de la siguiente manera: 'principio:final', en el caso de fruta[:], lo que hace es coger la cadena
entera, por lo que si fruta = 'Manzana', print(fruta) imprimira 'Manzana' al completo"""

