#Escribir un programa que muestre por pantalla el resultado de la siguiente operación
#aritmética

resultado = print(((3+2)/(2*5))**2)
print("El resultado de la operación es: ",resultado)