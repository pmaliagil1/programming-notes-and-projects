#Calcular la serie de Fibonacci hasta un número dado 

limite = int(input("Introduce un número para el limite: "))

a = 0
b = 1

while a<=limite:
    print(a)
    a,b=b,a+b
