#Escribir un programa que pregunte el nombre del usuario en la consola y un número 
#entero e imprima por pantalla en líneas distintas el nombre del usuario tantas veces como 
#el número introducido.

nombre = input("Introduzca su nombre de usuario: ")
n = int(input("Introduzca el número de veces que quiere escribirlo: "))
for i in range (1,n+1):
    print(nombre)