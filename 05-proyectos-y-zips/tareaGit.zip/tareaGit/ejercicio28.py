#Calcular el área de un triángulo a partir de tres lados 


lado1 = float(input("Introduce el primer lado: "))
lado2 = float(input("Introduce el segundo lado: "))
lado3 = float(input("Introduce el tercer lado: "))

#aplico la fórmula de Herón
semiperimetro = ((lado1 + lado2 + lado3)/2)
area = (semiperimetro * (semiperimetro - lado1) * (semiperimetro - lado2) * (semiperimetro - lado3)) ** 0.5
print("El area de el triángulo es:{:8.2f} ".format(area))
#APRENDER A USAR EL FORMAT
