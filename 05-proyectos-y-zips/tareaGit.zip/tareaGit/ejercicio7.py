#Escribe un programa que solicite tres números al usuario y calcule e imprima por pantalla
#su suma.

numero1 = int(input("Escribe un primer número: "))
numero2 = int(input("Escribe un segundo número: "))
numero3 = int(input("Escribe un tercer número: "))

suma = numero1 + numero2 + numero3

print("La suma de los tres números es de: ",suma)
