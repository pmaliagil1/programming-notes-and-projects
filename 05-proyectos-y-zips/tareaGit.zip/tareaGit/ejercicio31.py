#Mostrar todos los divisores de un número

numero = int(input("Introduce un número para ver todos sus divisores: "))

if numero < 1:
    print("Numero no valido")

else:
    es_divisor = False
    for i in range(1,numero):
        if numero % i == 0:
            es_divisor = True
            print(i)
        else:
            continue
