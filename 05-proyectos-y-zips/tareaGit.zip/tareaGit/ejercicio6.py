#Escribe un programa que pida el importe final de un artículo y calcule e imprima por
#pantalla el IVA que se ha pagado y el importe sin IVA (suponiendo que se ha aplicado un
#tipo de IVA del 10%).

precio_final = float(input("Precio final (10%): "))

precio_sin_iva = precio_final / 1.10
iva_pagado = precio_final - precio_sin_iva

print("IVA pagado:", round(iva_pagado, 2))
print("Precio sin IVA:", round(precio_sin_iva, 2))