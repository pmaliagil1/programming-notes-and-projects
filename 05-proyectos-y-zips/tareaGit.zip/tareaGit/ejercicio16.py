#Una panadería vende barras de pan a 3.49€ cada una. El pan que no es el día tiene un 
#descuento del 60%. Escribir un programa que comience leyendo el número de barras 
#vendidas que no son del día. Después el programa debe mostrar el precio habitual de una 
#barra de pan (establecido en el programa como una constante), el descuento que se le hace 
#por no ser fresca y el coste final total de todas las barras no frescas.

pan = 3.49
descuento = 0.60

barrasVendidas = int(input("Introduce el número de barras que no son del día vendidas: "))

precioSinDescuento = barrasVendidas * pan
precioConDescuento = precioSinDescuento * (1 - descuento)

print("El precio de una barra de pan es de:", pan, "€")
print("Descuento por no ser del día:", descuento * 100, "%")
print("Precio total sin descuento:", round(precioSinDescuento, 2), "€")
print("Precio total con descuento:", round(precioConDescuento, 2), "€")
