#Escribe un programa que le pida al usuario una temperatura en grados Celsius, la
#convierta a grados Fahrenheit e imprima por pantalla la temperatura convertida.

celsius = int(input("Escribe una temperatura en grados Celsius para pasarla a Farenheit: "))
farenheit = (celsius *1.8) + 32
print(celsius,"º celsius son equivalentes a ",farenheit," grados farenheit")