# Descomposicion factorial

numero = int(input("Introduce un número para hacer la descomposicion factorial: "))
factorial = 1
for i in range(1,numero + 1):
    factorial = factorial * i

print(factorial)