#Escribir un programa que pida al usuario dos números enteros y muestre por pantalla los
#siguienteS: "la división de n entre m da un cociente c y un resto r", donde n y m son los
#números introducidos por el usuario, y c y r son el cociente y el resto de la división entera
#respectivamente.

n = int(input("Introduce un primer número (n): "))
m = int(input("Introduce un segundo número (m): "))
c = n // m
r = n % m
print("El cociente es ",c," y el resto es ",r)