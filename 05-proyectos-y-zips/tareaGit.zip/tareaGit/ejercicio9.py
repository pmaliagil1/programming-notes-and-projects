#¿Es posible escribir el programa del ejercicio 1.7 sin usar variables? Inténtalo.
print("Escriba 3 números para ser sumados:")
print("La suma es de:", int(input()) + int(input()) + int(input()))