#Escribir un programa que pregunte por consola el precio de un producto en euros con dos 
#decimales y muestre por pantalla el número de euros y el número de céntimos del precio 
#introducido. 

precio = input("Introduzca el precio de un producto en euros con dos decimales (ejemplo: 1.99€): ")
euro,centimo = precio.split(".")
print("Número de euros:",euro,"\nNúmero de céntimos:",centimo.replace("€",""))
