#Escribe un programa que pida el importe sin IVA de un artículo y el tipo de IVA a aplicar
#y calcule e imprima por pantalla el precio final del artículo.
precioSinIva = int(input("Escriba el precio del producto sin IVA: "))
iva = int(input("Escriba el tipo de IVA que quiere aplicar: "))
precioConIva = precioSinIva * (1 + iva / 100)
print("El precio con el IVA aplicado es de ",precioConIva)
