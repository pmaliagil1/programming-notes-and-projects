#Cálculo de un número aleatorio entre dos valores

import random

valor1 = int(input("Introduce un primer valor: "))
valor2 = int(input("Introduce un segundo valor: "))

numero = random.randint(valor1, valor2)
print("El número aleatorio es: ",numero)
#Ya nos dejan usar f strings
#print(f"El número aleatorio es:{numero} ")
