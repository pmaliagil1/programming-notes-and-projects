#Escribir el programa del ejercicio 1.7 usando solamente dos variables diferentes.

numero1 = int(input("Escribe un primer número: "))
numero2 = int(input("Escribe un segundo número: "))

suma = numero1 + numero2 + numero2

print("La suma de los tres números es de: ",suma)