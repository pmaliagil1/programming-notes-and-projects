#Imagina que acabas de abrir una nueva cuenta de ahorros que te ofrece el 4% de interés 
#al año. Estos ahorros debido a intereses, que no se cobran hasta finales de año, se te añaden 
#al balance final de tu cuenta de ahorros. Escribir un programa que comience leyendo la 
#cantidad de dinero depositada en la cuenta de ahorros, introducida por el usuario. Después 
#el programa debe calcular y mostrar por pantalla la cantidad de ahorros tras el primer, 
#segundo y tercer años. Redondear cada cantidad a dos decimales.

dineroAhorrado = float(input("Introduce el dinero que vas a depositar: "))
interes = 0.04
print("Pasa el primer año (+4%)")
dineroAhorrado = dineroAhorrado * (1 + interes)
print("Dinero total: ", round(dineroAhorrado,2))
print("Pasa el segundo año (+4%)")
dineroAhorrado = dineroAhorrado * (1 + interes)
print("Dinero total: ", round(dineroAhorrado,2))
print("Pasa el tercer año (+4%)")
dineroAhorrado = dineroAhorrado * (1 + interes)
print("Dinero total: ", round(dineroAhorrado,2))

#Con bucles seria asi:

dineroAhorrado = float(input("Introduce el dinero que va a depositar: "))
interes = 0.04
for i in range(1,4):
    print("Año numero ",i,":")
    dineroAhorrado = dineroAhorrado * (1 + interes)
    print("Dinero total: ", round(dineroAhorrado,2))
