#Ejercicio 1: Subprograma que salude, sin parámetros

def saluda():
    print("Hola")
if __name__ == "__main__":
    saluda()