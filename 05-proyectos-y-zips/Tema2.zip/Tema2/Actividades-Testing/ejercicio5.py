"""Desarrolla una función en compara_numeros.py que reciba dos números y retorne el 
mayor número de los dos o 0 si son iguales. Realiza las pruebas unitarias y ejecútalas 
con pytest. 
Entrega lo siguiente:  
* Los ficheros compara_numeros.py y test_compara_numeros.py  
* Un pantallazo donde se muestre la vista del Explorador (View -> Explorer) con las 
carpetas y ficheros del proyecto.  
* Un pantallazo del terminal con las pruebas unitarias detalladas realizadas con éxito.  
* Fuerza un error en tu código, no en los tests, y muestra un pantallazo de tus pruebas 
unitarias realizadas de nuevo."""
