def suma(a: int, b: int) -> int:
    """
    Calcula la suma de dos números enteros.

    Parámetros
    ----------
    a : int
        Primer número entero.
    b : int
        Segundo número entero.

    Retorna
    -------
    int
        La suma de 'a' y 'b'.

    Ejemplos
    --------
    >>> suma(2, 3)
    5
    >>> suma(-1, 4)
    3
    """
    return a + b

print(help(suma))    #Esta línea está añadida para que salga la documentación en la terminal
                    #Al darle al botón de play sale diréctamente la documentación