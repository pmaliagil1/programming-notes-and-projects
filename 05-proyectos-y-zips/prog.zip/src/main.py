# src/main.py
def suma (num1, num2):
    return num1 + num2

def main():
    print("La suma de 3 + 2 es {}".format(suma(3, 2)))

if __name__ == "__main__":
    main()